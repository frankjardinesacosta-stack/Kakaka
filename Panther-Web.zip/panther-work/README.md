# Panther Patches — versión web

Proyecto web hecho con React, TypeScript, TanStack Start y Vite. Se abre en un navegador; no es un APK ni una aplicación de escritorio.

## Requisitos
- Node.js 22 o superior (recomendado).
- npm 10 o superior.

## Instalar y ejecutar en tu computadora
1. Descomprime este ZIP.
2. Abre una terminal dentro de la carpeta del proyecto.
3. Instala las dependencias:

   ```bash
   npm install
   ```

4. Inicia el servidor de desarrollo:

   ```bash
   npm run dev
   ```

5. Abre en el navegador la dirección local que indique Vite (normalmente `http://localhost:3000` o `http://localhost:5173`).

## Preparar la versión de producción

```bash
npm run build
npm run preview
```

El comando `preview` sirve para comprobar localmente la compilación de producción. Para publicarlo en Internet, sube el proyecto a un servicio compatible con TanStack Start/Nitro (por ejemplo, el flujo de publicación de Lovable si el proyecto sigue conectado allí) y configura el despliegue según el adaptador de ese servicio.

## Importante sobre los botones

La interfaz incluye un enlace al esquema `freefire://` cuando se activa un elemento. En un teléfono que tenga Free Fire instalado, el navegador puede ofrecer abrir esa aplicación. Esto no significa que el sitio instale archivos de parches ni modifique el juego: el código incluido en este proyecto no contiene un instalador Android ni un mecanismo de aplicación de esos archivos.
